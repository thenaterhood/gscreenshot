#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"


void
on_window_main_destroy                 (GtkObject       *object,
                                        gpointer         user_data)
{

}


void
on_button_all_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_window_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_selectarea_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_saveas_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}

